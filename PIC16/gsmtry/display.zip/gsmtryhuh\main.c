//INCLUDE MAIN HEADER FILE
#include"main.h"
int i=48,j=48,k=48;
//MAIN PROGRAM BEGINS
void main(void)
{
	unsigned char Count;
	MainSystemInitialize();
	LCDDisplayInitializing();
	
	
}

static void MainSystemInitialize(void)
{
	LCDInitialize();
	InitializeSerialCommunication();
}

