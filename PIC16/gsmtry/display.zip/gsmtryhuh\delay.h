#ifndef DELAY_H
#define DELAY_H

//FUNCTION PROTOTYPE
void Delay(unsigned int time);

//DEFINE USER DEFINED DATATYPE
typedef unsigned char ubyte;

#endif

